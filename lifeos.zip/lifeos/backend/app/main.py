from datetime import date
from fastapi import FastAPI, Depends, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session
from . import models as m, ai, auth
from .db import Base, engine, get_db
from .briefing import build_briefing
from .notify import start_scheduler

Base.metadata.create_all(engine)  # use Alembic migrations before production
app = FastAPI(title="LifeOS")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:3000"],
                   allow_methods=["*"], allow_headers=["*"])

@app.on_event("startup")
def _start(): start_scheduler()

class RegisterIn(BaseModel): email: str; password: str; monthly_income: float = 0
class ExpenseIn(BaseModel): amount: float; merchant: str = ""; category: str | None = None; date: date = date.today()
class TaskIn(BaseModel): title: str; due_date: date | None = None
class PaymentIn(BaseModel): title: str; amount: float; due_date: date
class SubIn(BaseModel): name: str; amount: float; next_charge: date
class DocIn(BaseModel): title: str; expires_on: date | None = None
class EditIn(BaseModel): amount: float | None = None; merchant: str | None = None; category: str | None = None
class AskIn(BaseModel): question: str

@app.post("/register")
def register(b: RegisterIn, db: Session = Depends(get_db)):
    if db.scalar(select(m.User).where(m.User.email == b.email)):
        raise HTTPException(400, "Email already registered")
    u = m.User(email=b.email, password_hash=auth.hash_pw(b.password), monthly_income=b.monthly_income)
    db.add(u); db.commit()
    return {"access_token": auth.make_token(u.id)}

@app.post("/login")
def login(f: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    u = db.scalar(select(m.User).where(m.User.email == f.username))
    if not u or not auth.check_pw(f.password, u.password_hash):
        raise HTTPException(401, "Wrong email or password")
    return {"access_token": auth.make_token(u.id)}

def crud(path, Model, Schema):
    """list / create / delete, always scoped to the logged-in user."""
    @app.get(f"/{path}")
    def lst(u=Depends(auth.current_user), db: Session = Depends(get_db)):
        return db.scalars(select(Model).where(Model.user_id == u.id)).all()

    @app.post(f"/{path}")
    def create(b: Schema, u=Depends(auth.current_user), db: Session = Depends(get_db)):
        data = b.model_dump()
        if Model is m.Expense:
            data["category"] = data["category"] or ai.categorize(data["merchant"])
        row = Model(user_id=u.id, **data); db.add(row); db.commit(); db.refresh(row); return row

    @app.delete(f"/{path}/{{rid}}")
    def delete(rid: int, u=Depends(auth.current_user), db: Session = Depends(get_db)):
        row = db.get(Model, rid)
        if not row or row.user_id != u.id: raise HTTPException(404)
        db.delete(row); db.commit(); return {"ok": True}

for p, M, S in [("expenses", m.Expense, ExpenseIn), ("tasks", m.Task, TaskIn), ("payments", m.Payment, PaymentIn),
                ("subscriptions", m.Subscription, SubIn), ("documents", m.Document, DocIn)]:
    crud(p, M, S)

@app.post("/receipts")
async def upload_receipt(file: UploadFile = File(...), u=Depends(auth.current_user), db: Session = Depends(get_db)):
    """OCR -> extraction -> saved as pending_review. Nothing counts as confirmed until the user approves."""
    info = ai.extract_receipt(ai.ocr(await file.read()))
    e = m.Expense(user_id=u.id, amount=info["total"] or 0, merchant=info["merchant"],
                  category=info["category"], source="receipt", status="pending_review")
    db.add(e); db.commit(); db.refresh(e)
    return e

@app.post("/expenses/{eid}/confirm")
def confirm(eid: int, edits: EditIn, u=Depends(auth.current_user), db: Session = Depends(get_db)):
    e = db.get(m.Expense, eid)
    if not e or e.user_id != u.id: raise HTTPException(404)
    for k, v in edits.model_dump(exclude_none=True).items(): setattr(e, k, v)
    e.status = "confirmed"; db.commit(); return e

@app.get("/briefing")
def briefing(u=Depends(auth.current_user), db: Session = Depends(get_db)):
    return build_briefing(db, u)

@app.post("/ask")
def ask(b: AskIn, u=Depends(auth.current_user), db: Session = Depends(get_db)):
    ctx = build_briefing(db, u, days=14)
    ans = ai.llm("You are LifeOS. Answer ONLY from the user's data below. If it isn't there, say you don't know. "
                 "Mark estimates as estimates. You can suggest actions but never claim to have done them.",
                 f"DATA:\n{ctx}\n\nQUESTION: {b.question}")
    return {"answer": ans or ctx["summary"]}
