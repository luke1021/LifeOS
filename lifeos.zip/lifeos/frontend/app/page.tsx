"use client";
import { useEffect, useState } from "react";
import { api } from "@/lib/api";

const rs = (n: number) => `Rs ${Math.round(n).toLocaleString()}`;

export default function Home() {
  const [token, setToken] = useState<string | null>(null);
  const [mode, setMode] = useState<"login" | "register">("login");
  const [f, setF] = useState({ email: "", password: "", income: "" });
  const [data, setData] = useState<any>(null);
  const [q, setQ] = useState(""); const [answer, setAnswer] = useState("");
  const [err, setErr] = useState("");

  useEffect(() => { setToken(localStorage.getItem("t")); }, []);
  const load = async (t = token) => t && setData(await api("/briefing", {}, t));
  useEffect(() => { load().catch(() => setToken(null)); }, [token]);

  async function auth() {
    try {
      const res = mode === "register"
        ? await api("/register", { method: "POST", body: JSON.stringify({ email: f.email, password: f.password, monthly_income: +f.income || 0 }) })
        : await api("/login", { method: "POST", body: new URLSearchParams({ username: f.email, password: f.password }) });
      localStorage.setItem("t", res.access_token); setToken(res.access_token); setErr("");
    } catch (e: any) { setErr(e.message); }
  }

  async function upload(file: File) {
    const body = new FormData(); body.append("file", file);
    await api("/receipts", { method: "POST", body }, token!); load();
  }
  const confirm = async (id: number) => { await api(`/expenses/${id}/confirm`, { method: "POST", body: "{}" }, token!); load(); };
  const ask = async () => setAnswer((await api("/ask", { method: "POST", body: JSON.stringify({ question: q }) }, token!)).answer);

  if (!token) return (
    <main className="mx-auto max-w-sm p-8 space-y-3">
      <h1 className="text-2xl font-semibold">LifeOS</h1>
      <input className="w-full border p-2 rounded" placeholder="Email" onChange={e => setF({ ...f, email: e.target.value })} />
      <input className="w-full border p-2 rounded" type="password" placeholder="Password" onChange={e => setF({ ...f, password: e.target.value })} />
      {mode === "register" && <input className="w-full border p-2 rounded" placeholder="Monthly income (Rs)" onChange={e => setF({ ...f, income: e.target.value })} />}
      {err && <p className="text-red-600 text-sm">{err}</p>}
      <button className="w-full bg-black text-white p-2 rounded" onClick={auth}>{mode === "login" ? "Log in" : "Create account"}</button>
      <button className="text-sm underline" onClick={() => setMode(mode === "login" ? "register" : "login")}>
        {mode === "login" ? "New here? Create an account" : "Have an account? Log in"}
      </button>
    </main>
  );

  if (!data) return <main className="p-8">Loading…</main>;
  const b = data.budget, w = data.this_week;
  const Row = ({ label, item }: any) => (
    <div className="flex justify-between py-1">
      <span>{label}</span>
      <span>{rs(item.value)} <em className="text-xs text-neutral-500">{item.certainty}</em></span>
    </div>);

  return (
    <main className="mx-auto max-w-3xl p-6 space-y-8">
      <p className="text-lg">{data.summary}</p>

      <section>
        <h2 className="font-semibold mb-2">This month</h2>
        <Row label="Income" item={b.income} /><Row label="Spent so far" item={b.spent_so_far} />
        <Row label="Already planned" item={b.planned_remaining_this_month} /><Row label="Left over" item={b.left_over} />
      </section>

      <section>
        <h2 className="font-semibold mb-2">Needs your attention</h2>
        {[...w.payments.map((p: any) => `Pay ${p.title} (${rs(p.amount)}) by ${p.due}`),
          ...w.tasks.map((t: any) => `${t.title}, due ${t.due}`),
          ...w.documents.map((d: any) => `${d.title} expires ${d.expires}`)]
          .map((s, i) => <p key={i} className="py-1">{s}</p>)}
        {!Object.values(w).flat().length && <p className="text-neutral-500">Nothing urgent. Add a task or payment to get started.</p>}
      </section>

      <section>
        <h2 className="font-semibold mb-2">Receipts to review</h2>
        {data.needs_your_review.map((e: any) => (
          <div key={e.id} className="flex justify-between items-center py-1">
            <span>{e.merchant || "Unknown merchant"}, {rs(e.amount)}, {e.category}</span>
            <button className="border px-3 py-1 rounded" onClick={() => confirm(e.id)}>Confirm</button>
          </div>))}
        <input type="file" accept="image/*" className="mt-2" onChange={e => e.target.files?.[0] && upload(e.target.files[0])} />
      </section>

      {data.possible_recurring.length > 0 && (
        <section>
          <h2 className="font-semibold mb-2">Possible forgotten subscriptions (estimated)</h2>
          {data.possible_recurring.map((r: any) => <p key={r.merchant}>{r.merchant}, about {rs(r.typical_amount)}/month</p>)}
        </section>)}

      <section>
        <h2 className="font-semibold mb-2">Ask LifeOS</h2>
        <div className="flex gap-2">
          <input className="flex-1 border p-2 rounded" value={q} onChange={e => setQ(e.target.value)} placeholder="What do I need to take care of this week?" />
          <button className="bg-black text-white px-4 rounded" onClick={ask}>Ask</button>
        </div>
        {answer && <p className="mt-3 whitespace-pre-wrap">{answer}</p>}
      </section>
    </main>
  );
}
