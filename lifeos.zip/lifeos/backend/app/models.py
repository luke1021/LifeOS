from datetime import date
from sqlalchemy import ForeignKey, String, Float, Date, Boolean
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String, unique=True, index=True)
    password_hash: Mapped[str]
    monthly_income: Mapped[float] = mapped_column(Float, default=0)

class Owned:
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), index=True)

class Expense(Base, Owned):
    __tablename__ = "expenses"
    id: Mapped[int] = mapped_column(primary_key=True)
    amount: Mapped[float]
    merchant: Mapped[str] = mapped_column(String, default="")
    category: Mapped[str] = mapped_column(String, default="other")
    date: Mapped[date] = mapped_column(Date, default=date.today)
    source: Mapped[str] = mapped_column(String, default="manual")           # manual | receipt
    status: Mapped[str] = mapped_column(String, default="confirmed")        # confirmed | pending_review

class Task(Base, Owned):
    __tablename__ = "tasks"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str]
    due_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    done: Mapped[bool] = mapped_column(Boolean, default=False)

class Payment(Base, Owned):
    __tablename__ = "payments"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str]
    amount: Mapped[float]
    due_date: Mapped[date] = mapped_column(Date)
    paid: Mapped[bool] = mapped_column(Boolean, default=False)

class Subscription(Base, Owned):
    __tablename__ = "subscriptions"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str]
    amount: Mapped[float]
    next_charge: Mapped[date] = mapped_column(Date)

class Document(Base, Owned):
    __tablename__ = "documents"
    id: Mapped[int] = mapped_column(primary_key=True)
    title: Mapped[str]
    expires_on: Mapped[date | None] = mapped_column(Date, nullable=True)
