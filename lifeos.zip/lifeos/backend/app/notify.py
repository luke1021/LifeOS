import os, smtplib
from email.message import EmailMessage
from apscheduler.schedulers.background import BackgroundScheduler
from sqlalchemy import select
from .db import SessionLocal
from . import models as m
from .briefing import build_briefing

def send_email(to: str, subject: str, body: str):
    host = os.getenv("SMTP_HOST")
    if not host:
        print(f"[email skipped, no SMTP_HOST] {to}: {subject}\n{body}"); return
    msg = EmailMessage(); msg["To"], msg["From"], msg["Subject"] = to, os.getenv("SMTP_USER"), subject
    msg.set_content(body)
    with smtplib.SMTP_SSL(host) as s:
        s.login(os.getenv("SMTP_USER"), os.getenv("SMTP_PASS")); s.send_message(msg)

def daily_digest():
    with SessionLocal() as db:
        for u in db.scalars(select(m.User)):
            b = build_briefing(db, u, days=3)
            if any(b["this_week"].values()):
                send_email(u.email, "LifeOS: coming up", b["summary"])

def start_scheduler():
    s = BackgroundScheduler(); s.add_job(daily_digest, "cron", hour=7); s.start()
