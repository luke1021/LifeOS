from collections import defaultdict
from datetime import date, timedelta
from sqlalchemy import select
from sqlalchemy.orm import Session
from . import models as m, ai

def _month_end(d: date) -> date:
    return (d.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)

def find_recurring(db: Session, user: m.User) -> list[dict]:
    """Suggestions only (estimates). Merchant seen 3+ times at ~monthly gaps, not already a subscription."""
    known = {s.name.lower() for s in db.scalars(select(m.Subscription).where(m.Subscription.user_id == user.id))}
    groups = defaultdict(list)
    for e in db.scalars(select(m.Expense).where(m.Expense.user_id == user.id, m.Expense.status == "confirmed")):
        if e.merchant:
            groups[e.merchant.strip().lower()].append(e)
    found = []
    for name, rows in groups.items():
        rows.sort(key=lambda e: e.date)
        gaps = [(b.date - a.date).days for a, b in zip(rows, rows[1:])]
        if len(rows) >= 3 and all(25 <= g <= 35 for g in gaps) and name not in known:
            found.append({"merchant": name, "typical_amount": rows[-1].amount,
                          "next_expected": str(rows[-1].date + timedelta(days=30)), "certainty": "estimate"})
    return found

def build_briefing(db: Session, user: m.User, days: int = 7) -> dict:
    today = date.today(); horizon = today + timedelta(days=days); month_start = today.replace(day=1)
    q = lambda M: select(M).where(M.user_id == user.id)
    expenses = db.scalars(q(m.Expense).where(m.Expense.date >= month_start)).all()
    confirmed = sum(e.amount for e in expenses if e.status == "confirmed")
    pending = [e for e in expenses if e.status == "pending_review"]
    payments = db.scalars(q(m.Payment).where(m.Payment.paid == False)).all()  # noqa: E712
    subs = db.scalars(q(m.Subscription)).all()
    me = _month_end(today)
    planned = sum(p.amount for p in payments if p.due_date <= me) + \
              sum(s.amount for s in subs if today <= s.next_charge <= me)
    data = {
        "this_week": {
            "tasks": [{"id": t.id, "title": t.title, "due": str(t.due_date)} for t in
                      db.scalars(q(m.Task).where(m.Task.done == False))  # noqa: E712
                      if t.due_date and t.due_date <= horizon],
            "payments": [{"id": p.id, "title": p.title, "amount": p.amount, "due": str(p.due_date)}
                         for p in payments if p.due_date <= horizon],
            "documents": [{"id": d.id, "title": d.title, "expires": str(d.expires_on)} for d in
                          db.scalars(q(m.Document)) if d.expires_on and d.expires_on <= today + timedelta(days=30)],
        },
        "budget": {
            "income": {"value": user.monthly_income, "certainty": "confirmed"},
            "spent_so_far": {"value": confirmed, "certainty": "confirmed"},
            "planned_remaining_this_month": {"value": planned, "certainty": "confirmed"},
            "left_over": {"value": user.monthly_income - confirmed - planned, "certainty": "estimate"},
        },
        "needs_your_review": [{"id": e.id, "merchant": e.merchant, "amount": e.amount,
                               "category": e.category} for e in pending],
        "possible_recurring": find_recurring(db, user),
    }
    data["summary"] = ai.llm(
        "Summarise what the user must handle this week in under 120 words. Use ONLY the JSON given. "
        "Never invent items. Say 'estimated' for anything marked estimate. Do not claim any action was taken.",
        str(data)) or _template(data)
    return data

def _template(d: dict) -> str:
    w = d["this_week"]
    return (f"This week: {len(w['tasks'])} task(s), {len(w['payments'])} payment(s) due, "
            f"{len(w['documents'])} document(s) needing attention. "
            f"{len(d['needs_your_review'])} receipt(s) await your review.")
