import io, json, os, re

RULES = {
    "groceries": ["super u", "winners", "jumbo", "intermart", "shoprite", "supermarket", "hyper"],
    "transport": ["bus", "taxi", "uber", "engen", "shell", "vivo", "petrol", "fuel"],
    "education": ["university", "uom", "utm", "tuition", "school", "course"],
    "bills": ["ceb", "cwa", "mauritius telecom", "emtel", "my.t", "internet", "electricity"],
    "food": ["restaurant", "cafe", "pizza", "burger", "snack"],
    "health": ["pharmacy", "clinic", "hospital", "doctor"],
}

def categorize(text: str) -> str:
    t = text.lower()
    for cat, words in RULES.items():
        if any(w in t for w in words):
            return cat
    return "other"

def llm(system: str, user: str, max_tokens: int = 600) -> str | None:
    """Returns None when no API key is configured, so every feature has a non-AI fallback."""
    if not os.getenv("ANTHROPIC_API_KEY"):
        return None
    import anthropic
    r = anthropic.Anthropic().messages.create(
        model=os.getenv("LLM_MODEL", "claude-sonnet-5-5"), max_tokens=max_tokens,
        system=system, messages=[{"role": "user", "content": user}])
    return r.content[0].text

def ocr(image_bytes: bytes) -> str:
    try:
        import pytesseract
        from PIL import Image
        return pytesseract.image_to_string(Image.open(io.BytesIO(image_bytes)))
    except Exception:
        return ""

def extract_receipt(text: str) -> dict:
    """Structured extraction: LLM if available, regex fallback. Output is always reviewed by the user."""
    out = llm(
        "Extract receipt data. Reply with JSON only: "
        '{"merchant": str, "total": number|null, "category": one of groceries|transport|education|bills|food|health|other}. '
        "Use null if unsure; never guess.", text[:4000])
    if out:
        try:
            d = json.loads(re.search(r"\{.*\}", out, re.S).group())
            return {"merchant": d.get("merchant") or "", "total": d.get("total"),
                    "category": d.get("category") or categorize(text)}
        except Exception:
            pass
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    nums = re.findall(r"total[^\d]{0,15}([\d.,]+)", text, re.I)
    total = float(nums[-1].replace(",", "")) if nums else None
    return {"merchant": lines[0] if lines else "", "total": total, "category": categorize(text)}
