const API = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export async function api(path: string, opts: RequestInit = {}, token?: string) {
  const headers: Record<string, string> = { ...(opts.headers as any) };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (opts.body && typeof opts.body === "string") headers["Content-Type"] = "application/json";
  const r = await fetch(`${API}${path}`, { ...opts, headers });
  if (!r.ok) throw new Error((await r.json().catch(() => ({}))).detail ?? "Request failed");
  return r.json();
}
